select avg(Population) from City;
