select sum(Population) from Country;
