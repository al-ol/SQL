select count(distinct GovernmentForm) from Country;
