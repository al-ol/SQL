select count(*) from City;
