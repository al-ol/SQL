select avg(Population) from Country;
