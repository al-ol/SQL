select Name, max(SurfaceArea) from Country;
