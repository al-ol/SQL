select Name, min(1.0*Population/SurfaceArea), max(1.0*Population/SurfaceArea)
from Country;
