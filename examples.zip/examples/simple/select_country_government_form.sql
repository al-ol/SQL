select distinct GovernmentForm from Country;
