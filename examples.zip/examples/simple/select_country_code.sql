select Code from Country;
