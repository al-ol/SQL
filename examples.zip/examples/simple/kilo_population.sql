select Name, Population / 1000 from Country;
