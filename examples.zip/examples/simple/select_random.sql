select Name, random() from Country;
