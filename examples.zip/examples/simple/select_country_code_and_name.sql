select Code, Name from Country;
