select * from Country;
