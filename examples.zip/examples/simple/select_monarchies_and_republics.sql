select * from Country
where GovernmentForm in ('Monarchy', 'Republic');
