select Name from Country
where GovernmentForm like '%Monarchy%';
