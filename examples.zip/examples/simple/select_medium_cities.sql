select Name, Population from City
where Population between 500000 and 1000000;
