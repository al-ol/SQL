select Name from Country
where GovernmentForm like '%Monarchy%'
and Population >= 1000000;
