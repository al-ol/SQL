select Name from Country
where Population >= 1000000;
