select Name from Country order by SurfaceArea desc limit 10;
