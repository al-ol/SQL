select City.Name
from City inner join Capital on City.Id = Capital.CityId;
